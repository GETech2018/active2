﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_spo2_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_calorie_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_heart_rate_text_text_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_time_pointer_minute = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let normal_heart_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 406,
              y: 268,
              font_array: ["L0102.png","L0103.png","L0104.png","L0105.png","L0106.png","L0107.png","L0108.png","L0109.png","L0110.png","L0111.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 249,
              y: 260,
              src: 'BT OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 209,
              y: 262,
              src: 'ALARM.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 311,
              y: 267,
              font_array: ["L0102.png","L0103.png","L0104.png","L0105.png","L0106.png","L0107.png","L0108.png","L0109.png","L0110.png","L0111.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 372,
              year_startY: 147,
              year_sc_array: ["Time06_0.png","Time06_1.png","Time06_2.png","Time06_3.png","Time06_4.png","Time06_5.png","Time06_6.png","Time06_7.png","Time06_8.png","Time06_9_P.png"],
              year_tc_array: ["Time06_0.png","Time06_1.png","Time06_2.png","Time06_3.png","Time06_4.png","Time06_5.png","Time06_6.png","Time06_7.png","Time06_8.png","Time06_9_P.png"],
              year_en_array: ["Time06_0.png","Time06_1.png","Time06_2.png","Time06_3.png","Time06_4.png","Time06_5.png","Time06_6.png","Time06_7.png","Time06_8.png","Time06_9_P.png"],
              year_zero: 1,
              year_space: -1,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 375,
              month_startY: 128,
              month_sc_array: ["mois_01.png","mois_02.png","mois_03.png","mois_04.png","mois_05.png","mois_06.png","mois_07.png","mois_08.png","mois_09.png","mois_10.png","mois_11.png","mois_12.png"],
              month_tc_array: ["mois_01.png","mois_02.png","mois_03.png","mois_04.png","mois_05.png","mois_06.png","mois_07.png","mois_08.png","mois_09.png","mois_10.png","mois_11.png","mois_12.png"],
              month_en_array: ["mois_01.png","mois_02.png","mois_03.png","mois_04.png","mois_05.png","mois_06.png","mois_07.png","mois_08.png","mois_09.png","mois_10.png","mois_11.png","mois_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 215,
              y: 298,
              src: 'Km1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 139,
              y: 310,
              font_array: ["L0102.png","L0103.png","L0104.png","L0105.png","L0106.png","L0107.png","L0108.png","L0109.png","L0110.png","L0111.png"],
              padding: false,
              h_space: -3,
              dot_image: 'K0097.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 270,
              y: 298,
              src: 'walk2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 309,
              font_array: ["L0102.png","L0103.png","L0104.png","L0105.png","L0106.png","L0107.png","L0108.png","L0109.png","L0110.png","L0111.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 77,
              font_array: ["L0102.png","L0103.png","L0104.png","L0105.png","L0106.png","L0107.png","L0108.png","L0109.png","L0110.png","L0111.png"],
              padding: false,
              h_space: -3,
              dot_image: 'K0097.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 77,
              font_array: ["L0102.png","L0103.png","L0104.png","L0105.png","L0106.png","L0107.png","L0108.png","L0109.png","L0110.png","L0111.png"],
              padding: false,
              h_space: -3,
              dot_image: 'K0097.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 343,
              font_array: ["d0003.png","d0004.png","d0005.png","d0006.png","d0007.png","d0008.png","d0009.png","d0010.png","d0011.png","d0012.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'd0014.png',
              unit_tc: 'd0014.png',
              unit_en: 'd0014.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 140,
              y: 355,
              image_array: ["img_bat_1.png","img_bat_2.png","img_bat_3.png","img_bat_4.png","img_bat_5.png","img_bat_6.png","img_bat_7.png","img_bat_8.png","img_bat_9.png","img_bat_10.png","img_bat_11.png","img_bat_12.png","img_bat_13.png","img_bat_14.png","img_bat_15.png","img_bat_16.png","img_bat_17.png","img_bat_18.png"],
              image_length: 18,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 139,
              day_startY: 130,
              day_sc_array: ["ACT_00.png","ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png"],
              day_tc_array: ["ACT_00.png","ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png"],
              day_en_array: ["ACT_00.png","ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 210,
              y: 133,
              week_en: ["j00.png","j01.png","j02.png","j03.png","j04.png","j05.png","j06.png"],
              week_tc: ["j00.png","j01.png","j02.png","j03.png","j04.png","j05.png","j06.png"],
              week_sc: ["j00.png","j01.png","j02.png","j03.png","j04.png","j05.png","j06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 37,
              y: -7,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 22,
              font_array: ["ACT1_0.png","ACT1_1.png","ACT1_2.png","ACT1_3.png","ACT1_4.png","ACT1_5.png","ACT1_6.png","ACT1_7.png","ACT1_8.png","ACT1_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ACT_11.png',
              unit_tc: 'ACT_11.png',
              unit_en: 'ACT_11.png',
              negative_image: 'ACT_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 187,
              hour_startY: 184,
              hour_array: ["Time4_0.png","Time4_1.png","Time4_2.png","Time4_3.png","Time4_4.png","Time4_5.png","Time4_6.png","Time4_7.png","Time4_8.png","Time4_9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 298,
              minute_startY: 184,
              minute_array: ["Time6_0.png","Time6_1.png","Time6_2.png","Time6_3.png","Time6_4.png","Time6_5.png","Time6_6.png","Time6_7.png","Time6_8.png","Time6_9.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 410,
              second_startY: 196,
              second_array: ["ACT1_0.png","ACT1_1.png","ACT1_2.png","ACT1_3.png","ACT1_4.png","ACT1_5.png","ACT1_6.png","ACT1_7.png","ACT1_8.png","ACT1_9.png"],
              second_zero: 1,
              second_space: -1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 262,
              y: 367,
              font_array: ["ACT1_0.png","ACT1_1.png","ACT1_2.png","ACT1_3.png","ACT1_4.png","ACT1_5.png","ACT1_6.png","ACT1_7.png","ACT1_8.png","ACT1_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '37.png',
              second_centerX: 93,
              second_centerY: 231,
              second_posX: 55,
              second_posY: 66,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'COEUR.png',
              minute_centerX: 361,
              minute_centerY: 379,
              minute_posX: 15,
              minute_posY: 10,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 249,
              y: 268,
              src: 'BT OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 184,
              y: 274,
              src: 'ALARM.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 283,
              day_startY: 130,
              day_sc_array: ["ACT_00.png","ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png"],
              day_tc_array: ["ACT_00.png","ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png"],
              day_en_array: ["ACT_00.png","ACT_01.png","ACT_02.png","ACT_03.png","ACT_04.png","ACT_05.png","ACT_06.png","ACT_07.png","ACT_08.png","ACT_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 119,
              y: 133,
              week_en: ["j00.png","j01.png","j02.png","j03.png","j04.png","j05.png","j06.png"],
              week_tc: ["j00.png","j01.png","j02.png","j03.png","j04.png","j05.png","j06.png"],
              week_sc: ["j00.png","j01.png","j02.png","j03.png","j04.png","j05.png","j06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 118,
              hour_startY: 184,
              hour_array: ["Time4_0.png","Time4_1.png","Time4_2.png","Time4_3.png","Time4_4.png","Time4_5.png","Time4_6.png","Time4_7.png","Time4_8.png","Time4_9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 232,
              minute_startY: 184,
              minute_array: ["Time6_0.png","Time6_1.png","Time6_2.png","Time6_3.png","Time6_4.png","Time6_5.png","Time6_6.png","Time6_7.png","Time6_8.png","Time6_9.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 338,
              second_startY: 185,
              second_array: ["ACT1_0.png","ACT1_1.png","ACT1_2.png","ACT1_3.png","ACT1_4.png","ACT1_5.png","ACT1_6.png","ACT1_7.png","ACT1_8.png","ACT1_9.png"],
              second_zero: 1,
              second_space: -1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 125,
              y: 205,
              w: 108,
              h: 85,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}