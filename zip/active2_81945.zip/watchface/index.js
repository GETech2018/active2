﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Prioris24hrDial(466x466).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 310,
              y: 307,
              src: 'BluetoothNo.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 109,
              y: 307,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 153,
              y: 130,
              image_array: ["Battery005.png","Battery010.png","Battery015.png","Battery020.png","Battery025.png","Battery030.png","Battery035.png","Battery040.png","Battery045.png","Battery050.png","Battery055.png","Battery060.png","Battery065.png","Battery070.png","Battery075.png","Battery080.png","Battery085.png","Battery090.png","Battery095.png","Battery100.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 255,
              day_startY: 315,
              day_sc_array: ["DateDigits0.png","DateDigits1.png","DateDigits2.png","DateDigits3.png","DateDigits4.png","DateDigits5.png","DateDigits6.png","DateDigits7.png","DateDigits8.png","DateDigits9.png"],
              day_tc_array: ["DateDigits0.png","DateDigits1.png","DateDigits2.png","DateDigits3.png","DateDigits4.png","DateDigits5.png","DateDigits6.png","DateDigits7.png","DateDigits8.png","DateDigits9.png"],
              day_en_array: ["DateDigits0.png","DateDigits1.png","DateDigits2.png","DateDigits3.png","DateDigits4.png","DateDigits5.png","DateDigits6.png","DateDigits7.png","DateDigits8.png","DateDigits9.png"],
              day_zero: 0,
              day_space: -4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 170,
              y: 315,
              week_en: ["Days1.png","Days2.png","Days3.png","Days4.png","Days5.png","Days6.png","Days7.png"],
              week_tc: ["Days1.png","Days2.png","Days3.png","Days4.png","Days5.png","Days6.png","Days7.png"],
              week_sc: ["Days1.png","Days2.png","Days3.png","Days4.png","Days5.png","Days6.png","Days7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			// Create the hour hand using IMG widget
			normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.IMG, {
			  x: 0, // The x-coordinate of the top-left corner of the Hands-Hour.png
			  y: 0, // The y-coordinate of the top-left corner of the Hands-Hour.png
			  src: 'Hands-Hour.png', // Your hour hand image
			  center_x: 233, // The x-coordinate of the rotation pivot point within the Hands-Hour.png image relative to its top-left corner.
			  center_y: 233, // The y-coordinate of the rotation pivot point within the Hands-Hour.png image 
			  angle: 0,      // Initial angle
			});

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hands-Minute.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 24,
              minute_posY: 222,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hands-Seconds.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 24,
              second_posY: 222,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenAOD');
			// Function to update the hour hand's angle
			this.updateHourHand = () => { // Changed to arrow function to preserve 'this' context if needed
              let now = hmSensor.createSensor(hmSensor.id.TIME);
              let hour = now.hour;     // Current hour (0–23)
              let minute = now.minute; // Current minute (0–59)
              let angle = (hour * 60 + minute) / 4 + 180; // 360*(hour*60+minute)/(24*60) + 180
              normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.ANGLE, angle);
              logger.log('updateHourHand called. Hour:' + hour + ' Minute:' + minute + ' Angle:' + angle); // Debug log
            };

			// Store the timer ID
            let hourHandTimer = null;

            // Start the timer
            this.startHourHandTimer = () => {
                if (this.hourHandTimer) { timer.stopTimer(this.hourHandTimer); } // Use this.hourHandTimer
                this.updateHourHand(); // Call immediately when starting the timer
                this.hourHandTimer = timer.createTimer(0, 60000, () => { this.updateHourHand(); }); // Use this.hourHandTimer and arrow function for callback
                logger.log('Timer started, ID:' + this.hourHandTimer); // Debug log
            };

            // Stop the timer
            this.stopHourHandTimer = () => {if (this.hourHandTimer) {timer.stopTimer(this.hourHandTimer);this.hourHandTimer = null;logger.log('Timer stopped');}};

            // Initial start
            this.startHourHandTimer();

            },

            onInit()   {logger.log ('index page.js on init invoke');this.init_view();},
            build()    {logger.log ('index page.js on build invoke');},
            onResume() {logger.log ('index page.js on resume invoke'); if (this.startHourHandTimer) {this.startHourHandTimer();}}, // Restart the timer when resuming
            onDestroy(){logger.log ('index page.js on destroy invoke'); if (this.stopHourHandTimer) {this.stopHourHandTimer(); }},// Stop the timer when destroying
            onReady()  {console.log('index page.js on ready invoke')},
            onShow()   {console.log('index page.js on show invoke')},
            onHide()   {console.log('index page.js on hide invoke')}
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
