﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'WF.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 354,
              y: 335,
              image_array: ["Weather_1.png","Weather_2.png","Weather_3.png","Weather_4.png","Weather_5.png","Weather_6.png","Weather_7.png","Weather_8.png","Weather_9.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 290,
              font_array: ["black_digit_small_01.png","black_digit_small_02.png","black_digit_small_03.png","black_digit_small_04.png","black_digit_small_05.png","black_digit_small_06.png","black_digit_small_07.png","black_digit_small_08.png","black_digit_small_09.png","black_digit_small_10.png"],
              padding: false,
              h_space: -7,
              unit_sc: 'Degrees.png',
              unit_tc: 'Degrees.png',
              unit_en: 'Degrees.png',
              negative_image: '-.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 15,
              y: 216,
              font_array: ["white_digit_small_01.png","white_digit_small_02.png","white_digit_small_03.png","white_digit_small_04.png","white_digit_small_05.png","white_digit_small_06.png","white_digit_small_07.png","white_digit_small_08.png","white_digit_small_09.png","white_digit_small_10.png"],
              padding: false,
              h_space: -7,
              unit_sc: 'Percent.png',
              unit_tc: 'Percent.png',
              unit_en: 'Percent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 95,
              y: 212,
              image_array: ["Bat_0.png","Bat_1.png","Bat_2.png","Bat_3.png","Bat_4.png","Bat_5.png","Bat_6.png","Bat_7.png","Bat_8.png","Bat_9.png","Bat_10.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 348,
              month_startY: 140,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 348,
              day_startY: 95,
              day_sc_array: ["black_digit_small_01.png","black_digit_small_02.png","black_digit_small_03.png","black_digit_small_04.png","black_digit_small_05.png","black_digit_small_06.png","black_digit_small_07.png","black_digit_small_08.png","black_digit_small_09.png","black_digit_small_10.png"],
              day_tc_array: ["black_digit_small_01.png","black_digit_small_02.png","black_digit_small_03.png","black_digit_small_04.png","black_digit_small_05.png","black_digit_small_06.png","black_digit_small_07.png","black_digit_small_08.png","black_digit_small_09.png","black_digit_small_10.png"],
              day_en_array: ["black_digit_small_01.png","black_digit_small_02.png","black_digit_small_03.png","black_digit_small_04.png","black_digit_small_05.png","black_digit_small_06.png","black_digit_small_07.png","black_digit_small_08.png","black_digit_small_09.png","black_digit_small_10.png"],
              day_zero: 1,
              day_space: -7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 348,
              y: 215,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 30,
              y: 290,
              font_array: ["white_digit_small_01.png","white_digit_small_02.png","white_digit_small_03.png","white_digit_small_04.png","white_digit_small_05.png","white_digit_small_06.png","white_digit_small_07.png","white_digit_small_08.png","white_digit_small_09.png","white_digit_small_10.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 335,
              src: 'Steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 140,
              font_array: ["white_digit_small_01.png","white_digit_small_02.png","white_digit_small_03.png","white_digit_small_04.png","white_digit_small_05.png","white_digit_small_06.png","white_digit_small_07.png","white_digit_small_08.png","white_digit_small_09.png","white_digit_small_10.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 95,
              src: 'Heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 310,
              am_y: 182,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 310,
              pm_y: 182,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 130,
              hour_startY: 80,
              hour_array: ["Big_digit_01.png","Big_digit_02.png","Big_digit_03.png","Big_digit_04.png","Big_digit_05.png","Big_digit_06.png","Big_digit_07.png","Big_digit_08.png","Big_digit_09.png","Big_digit_10.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 130,
              minute_startY: 240,
              minute_array: ["Big_digit_01.png","Big_digit_02.png","Big_digit_03.png","Big_digit_04.png","Big_digit_05.png","Big_digit_06.png","Big_digit_07.png","Big_digit_08.png","Big_digit_09.png","Big_digit_10.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 310,
              second_startY: 264,
              second_array: ["small_digit_01.png","small_digit_02.png","small_digit_03.png","small_digit_04.png","small_digit_05.png","small_digit_06.png","small_digit_07.png","small_digit_08.png","small_digit_09.png","small_digit_10.png"],
              second_zero: 1,
              second_space: -5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 354,
              y: 335,
              image_array: ["Weather_1.png","Weather_2.png","Weather_3.png","Weather_4.png","Weather_5.png","Weather_6.png","Weather_7.png","Weather_8.png","Weather_9.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 290,
              font_array: ["black_digit_small_01.png","black_digit_small_02.png","black_digit_small_03.png","black_digit_small_04.png","black_digit_small_05.png","black_digit_small_06.png","black_digit_small_07.png","black_digit_small_08.png","black_digit_small_09.png","black_digit_small_10.png"],
              padding: false,
              h_space: -7,
              unit_sc: 'Degrees.png',
              unit_tc: 'Degrees.png',
              unit_en: 'Degrees.png',
              negative_image: '-.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 15,
              y: 216,
              font_array: ["white_digit_small_01.png","white_digit_small_02.png","white_digit_small_03.png","white_digit_small_04.png","white_digit_small_05.png","white_digit_small_06.png","white_digit_small_07.png","white_digit_small_08.png","white_digit_small_09.png","white_digit_small_10.png"],
              padding: false,
              h_space: -7,
              unit_sc: 'Percent.png',
              unit_tc: 'Percent.png',
              unit_en: 'Percent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 95,
              y: 212,
              image_array: ["Bat_0.png","Bat_1.png","Bat_2.png","Bat_3.png","Bat_4.png","Bat_5.png","Bat_6.png","Bat_7.png","Bat_8.png","Bat_9.png","Bat_10.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 348,
              month_startY: 140,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 348,
              day_startY: 95,
              day_sc_array: ["black_digit_small_01.png","black_digit_small_02.png","black_digit_small_03.png","black_digit_small_04.png","black_digit_small_05.png","black_digit_small_06.png","black_digit_small_07.png","black_digit_small_08.png","black_digit_small_09.png","black_digit_small_10.png"],
              day_tc_array: ["black_digit_small_01.png","black_digit_small_02.png","black_digit_small_03.png","black_digit_small_04.png","black_digit_small_05.png","black_digit_small_06.png","black_digit_small_07.png","black_digit_small_08.png","black_digit_small_09.png","black_digit_small_10.png"],
              day_en_array: ["black_digit_small_01.png","black_digit_small_02.png","black_digit_small_03.png","black_digit_small_04.png","black_digit_small_05.png","black_digit_small_06.png","black_digit_small_07.png","black_digit_small_08.png","black_digit_small_09.png","black_digit_small_10.png"],
              day_zero: 1,
              day_space: -7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 348,
              y: 215,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 310,
              am_y: 182,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 310,
              pm_y: 182,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 130,
              hour_startY: 80,
              hour_array: ["Big_digit_01.png","Big_digit_02.png","Big_digit_03.png","Big_digit_04.png","Big_digit_05.png","Big_digit_06.png","Big_digit_07.png","Big_digit_08.png","Big_digit_09.png","Big_digit_10.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 130,
              minute_startY: 240,
              minute_array: ["Big_digit_01.png","Big_digit_02.png","Big_digit_03.png","Big_digit_04.png","Big_digit_05.png","Big_digit_06.png","Big_digit_07.png","Big_digit_08.png","Big_digit_09.png","Big_digit_10.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 310,
              second_startY: 264,
              second_array: ["small_digit_01.png","small_digit_02.png","small_digit_03.png","small_digit_04.png","small_digit_05.png","small_digit_06.png","small_digit_07.png","small_digit_08.png","small_digit_09.png","small_digit_10.png"],
              second_zero: 1,
              second_space: -5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: 280,
              w: 100,
              h: 100,
              src: 'transparent.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: 85,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 16,
              y: 198,
              w: 113,
              h: 70,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 336,
              y: 198,
              w: 113,
              h: 70,
              src: 'transparent.png',
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 335,
              y: 64,
              w: 100,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 335,
              y: 276,
              w: 100,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}